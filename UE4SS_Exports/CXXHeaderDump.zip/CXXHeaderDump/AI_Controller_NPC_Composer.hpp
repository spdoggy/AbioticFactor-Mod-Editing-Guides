#ifndef UE4SS_SDK_AI_Controller_NPC_Composer_HPP
#define UE4SS_SDK_AI_Controller_NPC_Composer_HPP

class AAI_Controller_NPC_Composer_C : public AAbiotic_AI_Controller_ParentBP_C
{
}; // Size: 0x8B8

#endif
