#ifndef UE4SS_SDK_AnimBP_Composer_HPP
#define UE4SS_SDK_AnimBP_Composer_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_107;                                                         // 0x0004 (size: 0x8)
    TArray<float> __ArrayProperty_108;                                                // 0x0010 (size: 0x10)
    bool __BoolProperty_109;                                                          // 0x0020 (size: 0x1)
    float __FloatProperty_110;                                                        // 0x0024 (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_111;                               // 0x0028 (size: 0x2C)
    float __FloatProperty_112;                                                        // 0x0054 (size: 0x4)
    EAnimSyncMethod __EnumProperty_113;                                               // 0x0058 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_114;                             // 0x0059 (size: 0x1)
    FName __NameProperty_115;                                                         // 0x005C (size: 0x8)
    FName __NameProperty_116;                                                         // 0x0064 (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_117;                                        // 0x0070 (size: 0x20)
    class UBlendProfile* __BlendProfile_118;                                          // 0x0090 (size: 0x8)
    class UCurveFloat* __CurveFloat_119;                                              // 0x0098 (size: 0x8)
    bool __BoolProperty_120;                                                          // 0x00A0 (size: 0x1)
    EAlphaBlendOption __EnumProperty_121;                                             // 0x00A1 (size: 0x1)
    EBlendListTransitionType __EnumProperty_122;                                      // 0x00A2 (size: 0x1)
    TArray<float> __ArrayProperty_123;                                                // 0x00A8 (size: 0x10)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00B8 (size: 0x80)
    FAnimSubsystem_BlendSpaceGraph AnimBlueprintExtension_BlendSpaceGraph;            // 0x0138 (size: 0x18)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0150 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0168 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_1;      // 0x0198 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_4;       // 0x01C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceSampleResult_4; // 0x01F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x0228 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceSampleResult_3; // 0x0258 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceGraph_1;      // 0x0288 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x02B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceSampleResult_2; // 0x02E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0318 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceSampleResult_1; // 0x0348 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0378 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceSampleResult; // 0x03A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpaceGraph;        // 0x03D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0408 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_PoseSnapshot;           // 0x0438 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x0468 (size: 0x30)

}; // Size: 0x498

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    bool __BoolProperty;                                                              // 0x0001 (size: 0x1)
    bool __BoolProperty_0;                                                            // 0x0002 (size: 0x1)

}; // Size: 0x3

class UAnimBP_Composer_C : public UAbioticCharacterAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x3)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_BlendSpaceGraph;                    // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0398 (size: 0x20)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_1;                        // 0x03B8 (size: 0x48)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;                          // 0x0400 (size: 0x48)
    FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_4;          // 0x0448 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x0468 (size: 0x48)
    FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_3;          // 0x04B0 (size: 0x20)
    FAnimNode_BlendSpaceGraph AnimGraphNode_BlendSpaceGraph_1;                        // 0x04D0 (size: 0x68)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x0538 (size: 0x48)
    FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_2;          // 0x0580 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x05A0 (size: 0x48)
    FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_1;          // 0x05E8 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x0608 (size: 0x48)
    FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult;            // 0x0650 (size: 0x20)
    FAnimNode_BlendSpaceGraph AnimGraphNode_BlendSpaceGraph;                          // 0x0670 (size: 0x68)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x06D8 (size: 0x48)
    FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot;                                // 0x0720 (size: 0x90)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x07B0 (size: 0x48)
    double Speed;                                                                     // 0x07F8 (size: 0x8)
    double Direction;                                                                 // 0x0800 (size: 0x8)
    bool CombatMode;                                                                  // 0x0808 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void TryScreenshake();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void AnimNotify_GrabStart();
    void AnimNotify_GrabEnd();
    void AnimNotify_WalkScreenShake();
    void AnimNotify_AggroScreenShake();
    void ExecuteUbergraph_AnimBP_Composer(int32 EntryPoint);
}; // Size: 0x809

#endif
