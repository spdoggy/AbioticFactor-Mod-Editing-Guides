#ifndef UE4SS_SDK_BP_FishingHotspotManager_HPP
#define UE4SS_SDK_BP_FishingHotspotManager_HPP

class ABP_FishingHotspotManager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0298 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    TArray<class ABP_FishingHotspot_C*> Hotspots;                                     // 0x02B0 (size: 0x10)
    TArray<FVector> Linked;                                                           // 0x02C0 (size: 0x10)
    TArray<class ABP_FishingHotspot_C*> RuntimeHotspots;                              // 0x02D0 (size: 0x10)
    double HotspotDuration;                                                           // 0x02E0 (size: 0x8)
    double HotspotCooldown;                                                           // 0x02E8 (size: 0x8)

    void SetRandomHotspotActive(bool JustDisable);
    void UserConstructionScript();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_FishingHotspotManager(int32 EntryPoint);
}; // Size: 0x2F0

#endif
