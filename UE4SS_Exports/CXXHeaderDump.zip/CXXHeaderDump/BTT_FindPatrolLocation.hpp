#ifndef UE4SS_SDK_BTT_FindPatrolLocation_HPP
#define UE4SS_SDK_BTT_FindPatrolLocation_HPP

class UBTT_FindPatrolLocation_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    double AveragePatrolDistance;                                                     // 0x00B0 (size: 0x8)
    FVector Random Location;                                                          // 0x00B8 (size: 0x18)
    TSubclassOf<class UNavigationQueryFilter> OverrideNavQuery;                       // 0x00D0 (size: 0x8)

    void FindPatrolLocation(class AAIController* Controller, class APawn* Pawn, bool& Success);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindPatrolLocation(int32 EntryPoint);
}; // Size: 0xD8

#endif
