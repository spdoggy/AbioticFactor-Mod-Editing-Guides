#ifndef UE4SS_SDK_BuffActor_FriendFinder_HPP
#define UE4SS_SDK_BuffActor_FriendFinder_HPP

class ABuffActor_FriendFinder_C : public ABuffActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    class USphereComponent* OutlineOverlap;                                           // 0x02C8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02D0 (size: 0x8)
    TArray<class AAbiotic_Character_ParentBP_C*> PlayerList;                          // 0x02D8 (size: 0x10)

    void FriendCheck(class AAbiotic_Character_ParentBP_C* PotentialFriend, bool& CanShowOutline);
    void TryRemoveOutlineFromFriend(bool RemoveFromAll, class AActor* FriendToRemove, bool RemoveFromList);
    void TryOutlineFriend(bool OutlineToAll, class AActor* PotentialFriend, bool ForceUpdate);
    void CheckTargetFaction(class AActor* PotentialFriend, bool& Friend);
    void UpdateOutlineStatus(class AAbiotic_Character_ParentBP_C* OutlinedCharacter, bool Outline);
    void BndEvt__BuffActor_FriendFinder_OutlineOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BuffActor_FriendFinder_OutlineOverlap_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void RemoveFriendFromList(class AAbiotic_Character_ParentBP_C* OutlinedCharacter, bool Outline);
    void ForceUpdateFriends();
    void Server_OnBuffBeginPlay(FBuffDebuffRowHandle BuffRow);
    void Broadcast_OnBuffEndPlay(FBuffDebuffRowHandle BuffRow);
    void Broadcast_OnBuffBeginPlay(FBuffDebuffRowHandle BuffRow);
    void CheckOwnerHighlight();
    void Local_OnBuffEndPlay(FBuffDebuffRowHandle BuffRow);
    void Local_OnBuffBeginPlay(FBuffDebuffRowHandle BuffRow);
    void ExecuteUbergraph_BuffActor_FriendFinder(int32 EntryPoint);
}; // Size: 0x2E8

#endif
