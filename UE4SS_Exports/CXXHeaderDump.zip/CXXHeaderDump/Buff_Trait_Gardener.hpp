#ifndef UE4SS_SDK_Buff_Trait_Gardener_HPP
#define UE4SS_SDK_Buff_Trait_Gardener_HPP

class UBuff_Trait_Gardener_C : public UBuff_Trait_RecipeGranter_C
{
}; // Size: 0x78

#endif
