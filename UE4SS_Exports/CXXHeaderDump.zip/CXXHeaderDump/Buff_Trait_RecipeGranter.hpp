#ifndef UE4SS_SDK_Buff_Trait_RecipeGranter_HPP
#define UE4SS_SDK_Buff_Trait_RecipeGranter_HPP

class UBuff_Trait_RecipeGranter_C : public UBuffObject_ParentBP_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0060 (size: 0x8)
    TArray<FDataTableRowHandle> Recipes To Give;                                      // 0x0068 (size: 0x10)

    void Server_OnBuffApply(class AAbioticCharacter* Character);
    void ExecuteUbergraph_Buff_Trait_RecipeGranter(int32 EntryPoint);
}; // Size: 0x78

#endif
