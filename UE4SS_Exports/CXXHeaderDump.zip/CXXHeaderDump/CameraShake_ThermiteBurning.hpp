#ifndef UE4SS_SDK_CameraShake_ThermiteBurning_HPP
#define UE4SS_SDK_CameraShake_ThermiteBurning_HPP

class UCameraShake_ThermiteBurning_C : public UDefaultCameraShakeBase
{
}; // Size: 0xE0

#endif
