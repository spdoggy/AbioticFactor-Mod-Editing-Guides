#ifndef UE4SS_SDK_ComputerTerminal_Standard_Laptop_HPP
#define UE4SS_SDK_ComputerTerminal_Standard_Laptop_HPP

class AComputerTerminal_Standard_Laptop_C : public AComputerTerminal_Standard_C
{

    void UserConstructionScript();
}; // Size: 0x388

#endif
