#ifndef UE4SS_SDK_DamageType_Composed_HPP
#define UE4SS_SDK_DamageType_Composed_HPP

class UDamageType_Composed_C : public UDamageType_EnvironmentPhysics_C
{
}; // Size: 0x290

#endif
