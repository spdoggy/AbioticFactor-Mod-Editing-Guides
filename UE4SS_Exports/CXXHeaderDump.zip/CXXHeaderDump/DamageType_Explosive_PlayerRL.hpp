#ifndef UE4SS_SDK_DamageType_Explosive_PlayerRL_HPP
#define UE4SS_SDK_DamageType_Explosive_PlayerRL_HPP

class UDamageType_Explosive_PlayerRL_C : public UDamageType_Explosive_C
{
}; // Size: 0x290

#endif
