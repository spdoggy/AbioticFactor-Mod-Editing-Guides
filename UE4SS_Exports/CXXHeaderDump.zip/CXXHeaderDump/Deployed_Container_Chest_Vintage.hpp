#ifndef UE4SS_SDK_Deployed_Container_Chest_Vintage_HPP
#define UE4SS_SDK_Deployed_Container_Chest_Vintage_HPP

class ADeployed_Container_Chest_Vintage_C : public ADeployed_Container_ParentBP_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0940 (size: 0x8)
    class UStaticMeshComponent* Lid;                                                  // 0x0948 (size: 0x8)
    float LidAnimTimeline_NewTrack_0_288F481746BDF9ED0F24B781879F0348;                // 0x0950 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> LidAnimTimeline__Direction_288F481746BDF9ED0F24B781879F0348; // 0x0954 (size: 0x1)
    class UTimelineComponent* LidAnimTimeline;                                        // 0x0958 (size: 0x8)
    FRotator LidClosedRot;                                                            // 0x0960 (size: 0x18)
    FRotator LidOpenRot;                                                              // 0x0978 (size: 0x18)

    void GetHighlightComponents(TArray<class UActorComponent*>& Components, bool& DontHighlightPowerCord);
    void LidAnimTimeline__FinishedFunc();
    void LidAnimTimeline__UpdateFunc();
    void ToggleOpenFX(bool Open);
    void ExecuteUbergraph_Deployed_Container_Chest_Vintage(int32 EntryPoint);
}; // Size: 0x990

#endif
