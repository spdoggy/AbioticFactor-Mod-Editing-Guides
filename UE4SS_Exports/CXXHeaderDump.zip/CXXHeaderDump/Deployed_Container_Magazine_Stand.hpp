#ifndef UE4SS_SDK_Deployed_Container_Magazine_Stand_HPP
#define UE4SS_SDK_Deployed_Container_Magazine_Stand_HPP

class ADeployed_Container_Magazine_Stand_C : public ADeployed_Container_ParentBP_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0940 (size: 0x8)
    class UStaticMeshComponent* TrashTop;                                             // 0x0948 (size: 0x8)
    float Drawer_NewTrack_0_E6EF0BD24583BB69E107D9BE293FC941;                         // 0x0950 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Drawer__Direction_E6EF0BD24583BB69E107D9BE293FC941; // 0x0954 (size: 0x1)
    class UTimelineComponent* Drawer;                                                 // 0x0958 (size: 0x8)
    FVector LidClosed;                                                                // 0x0960 (size: 0x18)
    FVector LidOpen;                                                                  // 0x0978 (size: 0x18)

    void GetHighlightComponents(TArray<class UActorComponent*>& Components, bool& DontHighlightPowerCord);
    void Drawer__FinishedFunc();
    void Drawer__UpdateFunc();
    void ToggleOpenFX(bool Open);
    void ExecuteUbergraph_Deployed_Container_Magazine_Stand(int32 EntryPoint);
}; // Size: 0x990

#endif
