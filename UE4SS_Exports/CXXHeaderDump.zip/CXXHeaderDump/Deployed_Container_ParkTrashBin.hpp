#ifndef UE4SS_SDK_Deployed_Container_ParkTrashBin_HPP
#define UE4SS_SDK_Deployed_Container_ParkTrashBin_HPP

class ADeployed_Container_ParkTrashBin_C : public ADeployed_Container_ParentBP_C
{
    class UDecalComponent* Decal;                                                     // 0x0940 (size: 0x8)
    class UStaticMeshComponent* Seal;                                                 // 0x0948 (size: 0x8)
    FVector LidClosed;                                                                // 0x0950 (size: 0x18)
    FVector LidOpen;                                                                  // 0x0968 (size: 0x18)

    void GetHighlightComponents(TArray<class UActorComponent*>& Components, bool& DontHighlightPowerCord);
}; // Size: 0x980

#endif
