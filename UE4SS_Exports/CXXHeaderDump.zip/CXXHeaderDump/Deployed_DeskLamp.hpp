#ifndef UE4SS_SDK_Deployed_DeskLamp_HPP
#define UE4SS_SDK_Deployed_DeskLamp_HPP

class ADeployed_DeskLamp_C : public AAbioticDeployed_Lamp_ParentBP_C
{
}; // Size: 0x8E0

#endif
